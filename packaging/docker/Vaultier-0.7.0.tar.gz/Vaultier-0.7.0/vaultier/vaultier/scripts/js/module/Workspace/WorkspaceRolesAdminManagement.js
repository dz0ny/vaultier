'use strict';

Vaultier.WorkspaceRolesAdminManagementRoute = Vaultier.RolesAdminManagementRoute.extend(
    Vaultier.WorkspaceKeysMixin,
    Vaultier.WorkspaceMixin);

Vaultier.WorkspaceRolesAdminManagementController = Vaultier.RolesAdminManagementController.extend({});