'use strict';

var Service = Po.NS('Service');

Service.Environment = Ember.Object.extend({

    workspace: null,
    vault: null,
    card: null,
    secret: null,
    router: null

});