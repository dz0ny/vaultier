ApplicationLoader.hideLoader(1000);
Vaultier.advanceReadiness();
