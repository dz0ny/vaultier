Vaultier.EditorInput = Ember.TextArea.extend({
    classNames: ['vaultier-epic-editor-input']

});
