Vaultier.LayoutLayoutStandardView = Ember.View.extend({
    templateName: 'Layout/LayoutStandard'
});

Vaultier.LayoutLayoutWindowView = Ember.View.extend({
    templateName: 'Layout/LayoutStandard'
});

Vaultier.LayoutFooterView = Ember.View.extend({
    templateName: 'Layout/Footer'
});
