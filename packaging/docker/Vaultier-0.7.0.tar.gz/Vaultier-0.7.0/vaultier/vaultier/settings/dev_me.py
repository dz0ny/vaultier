from .dev import *

DEBUG = True

SECRET_KEY = 'asdfasdfasdf'

ALLOWED_HOSTS = []

INSTALLED_APPS += ('django_extensions', )

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': 'vaultier_t',
        'USER': 'root',
        'PASSWORD': 'secreet',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}


LOGGING = {
    'version': 1,
    'disable_existing_loggers': True,
    'formatters': {
        'default': {
            'format': '%(asctime)-15s %(name)-7s %(levelname)s: %(message)s',
            'datefmt': '%m/%d/%Y %H:%M:%S',
        },
    },
    'handlers': {
        'console': {
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
            'formatter': 'default'
        },
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'propagate': True,
            'level': 'INFO',
        },
        'master': {
            'handlers': ['console'],
            'propagate': True,
            'level': 'INFO',
        },
    }
}

# Indicates options for frontend
FT_FEATURES = {
    'dev_shared_key': True,  # for all users same private key is used
    'dev_show_token': True,  # Token is available to copy/paste in user profile box
    'dev_email': 'jakub.bokoc@rclick.cz',  # current developer email used for default logging when developing
}

# Indicates options for backend
BK_FEATURES = {
    'dev_mail_to': 'jakub.bokoc@rclick.cz',  # all emails goes to only this use
    'dev_shared_key': True,  # for all users same private key is used
    'ga_create_code': None,  # code for google analytics, on devel we don't want to track anything
    # 1 hour in milliseconds, used to calculate the expiration date of a lostkey resource
    'lostkey_hash_expiration_time': 3600000,
    'from_email': 'info@rclick.com',  # Default email address from which we send emails
    'login_safe_timestamp_delta': timedelta(seconds=15),  # Max difference between timestamp from server and from front-end in seconds

}
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

CELERY_ALWAYS_EAGER = False