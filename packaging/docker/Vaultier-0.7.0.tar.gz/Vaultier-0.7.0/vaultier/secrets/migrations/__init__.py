from south.modelsinspector import add_introspection_rules
add_introspection_rules([], ["^libs\.lowercasefield\.lowercasefield\."
                             "LowerCaseCharField"])
add_introspection_rules([], ["^secrets\.business\.fields\.SecretTypeField"])
