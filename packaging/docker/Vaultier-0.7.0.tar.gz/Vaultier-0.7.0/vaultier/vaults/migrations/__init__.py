from south.modelsinspector import add_introspection_rules
add_introspection_rules([], ["^libs\.lowercasefield\.lowercasefield\."
                             "LowerCaseCharField"])